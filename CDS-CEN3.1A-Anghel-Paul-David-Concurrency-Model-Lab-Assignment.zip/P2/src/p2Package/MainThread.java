package p2Package;

import java.util.Scanner;

public class MainThread {

	public static void main(String[] args) {
		
		int range;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Input the range: ");
		range = scan.nextInt();
		
		
		(new Counter("p",range)).start();
		(new Counter("q",range)).start();		
		
		
	}
}
