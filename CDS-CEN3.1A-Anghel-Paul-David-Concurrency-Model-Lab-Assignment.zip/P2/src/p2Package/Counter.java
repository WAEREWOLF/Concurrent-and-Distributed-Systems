package p2Package;

import java.util.ArrayList;

public class Counter extends Thread{
	
	/** 
     * @param message - is represented by the processes p and q  
     * @param n - is a static integer that is initialized with value 0
     * @param temp - is used as an auxiliary to dont lose the value of n
     * @param array - it is stored all the numbers in range
     * @param range - is a static int that is read by input in the MainThread class 
     */
	String message;
	public static int n = 0;
	private  int range;
	
	/**
	 * An ArrayList to store all the numbers within the given range
	 */
	ArrayList<Integer> array = new ArrayList<Integer>();
		
	public Counter(String m, int range) { 
		this.message = m;
		this.range = range;
	}
	
	public void run() {		
		
        for(int i  =  0;  i  <  range;  i++)  {
           int temp  =  n;
            n = temp + 1;
            array.add(i);
        }
        
        
        /**
	     *Printing the processes p and q, the array and the value of n
	     */
       
        System.out.println(message+" " + n + "\n" +array);
        System.out.println("n= " + n);		
	}
		

}
