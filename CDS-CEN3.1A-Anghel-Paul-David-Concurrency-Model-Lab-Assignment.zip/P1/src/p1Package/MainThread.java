package p1Package;

import java.util.ArrayList;
import java.util.Scanner;


public class MainThread {

	public static void main(String[] args) {
		
		int n; //maximum limit of the interval
		int kThreads; //number of threads
		int[] primeNumbersArray; //an Array that will contain prime numbers
		int executionStep;
		
		//variables that will keep the track of time during the execution
		long startedTime;
		long finishedTime;
		long elapsedTime;
		
		// Reading from input the max size of the interval and the numbers of threads (expecting integers numbers) using a Scanner
		Scanner scan = new Scanner(System.in);
		System.out.println("Please input the maximum size of the interval: ");
		n = scan.nextInt();
		System.out.println("The interval is [1,"+ n + "]\n");
		System.out.println("Please input the number of threads: ");
		kThreads = scan.nextInt();
		
		primeNumbersArray = new int[n]; //initializing the array with n elements
		PrimeNumbers[] qThreads = new PrimeNumbers[kThreads];// creating a vector with k threads
		
		startedTime = System.currentTimeMillis(); //Saving the current time which in this moment is actually the starting time of the execution in Ms
		
		PrimeNumbers.primeNumbersList = new ArrayList<Integer>(primeNumbersArray.length); // Accessing the primeNumbersList from PrimeNumbers class 
																						  // and creates an ArrayList of integers of the given size 
		executionStep = primeNumbersArray.length / kThreads + 1; // the length of the list is divided by the multiples of k+1
		
		for(int counter = 0; counter<kThreads; counter++) {   
			
			//I initialized every thread with the numbers that needs to be covered, starting from the beginning of the list 
			qThreads[counter] = new PrimeNumbers(counter * executionStep, Math.min(primeNumbersArray.length,  (counter + 1) * executionStep - 1));
			qThreads[counter].start(); //a new thread is created and the run() method from the PrimeNumbers class is executed
		}
        try {
        	
        	for(int counter = 0; counter < kThreads; counter++) 
        	{
        	//the thread is going into a waiting state. It remains in a waiting state until the referenced thread terminates
        		qThreads[counter].join();
        	}
        	
        }catch(Exception e) {
        	e.printStackTrace(); //If an exception will appear, it will be printed on the screen
        }
        
        finishedTime = System.currentTimeMillis(); //Saving the current time which in this moment is actually the finished time in Ms
        elapsedTime = finishedTime - startedTime; //Computing the total elapsed time subtracting the started time from the finished time
        
        //Printing the total prime numbers found with every thread (will be the same)  
        for(int counter = 0; counter <kThreads; counter++) {
        	System.out.println("Total prime numbers found  with thread " + counter + " : " + PrimeNumbers.primeNumbersList.size());
        }
        
        System.out.println("\nPrime numbers found are: \n" + PrimeNumbers.primeNumbersList); //Printing the list with all the prime numbers in the specified interval
        System.out.println("\nEstimated elapsed time is " + elapsedTime + " Ms"); //Printing the elapsed time in Ms
                
        
        
		
	}
}
