package p1Package;

import java.util.ArrayList;

public class PrimeNumbers extends Thread {
	
	 int start = 1; //The left limit of the interval is initialized with 1 (specified in the problem)
	 int end; //The right extremity of the interval 
	 static ArrayList<Integer> primeNumbersList; //Creating an ArrayList of integers that will contain all the prime numbers from the specified interval
	
	 //The Constructor where are assigned the extremities of the interval
	public PrimeNumbers(int start, int end) {
		this.start = start;
		this.end = end;
	}
	
	public void run() {
		
		//Algorithm: Sieve of Eratosthenes, adapted(is a simple algorithm that finds all the prime numbers up to any given limit)
		for (int i = start; i <= end; i++) {
			boolean ok = true; //variable for checking starting with true (supposing the number is prime)
			for (int j = 2; j < i; j++) {
				if (i % j == 0) { //testing if the current number has some divisors
					ok = false; //the variable ok is becoming false because it has some divisors
					break;
				}
			}
			
			if(ok == true) { // the number is prime
				if (i != 0 && i != 1) { // 1 and 0 are not prime numbers so we ignore them
					primeNumbersList.add(i); // we add the found prime number into the list
					
				}
			}

		}
	}

}
