
public class Channel<T> {
	private T chan = null;
	int ready = 0;
	
	public synchronized void send(T mes)
			throws InterruptedException {
			// the message is copied on the channel
			chan = mes;

			// notifies the receptors
			// ready = 1
			++ready;
			notifyAll();
			/**
			 *  The message is waiting to be taked by the receptors
			 *  the channel will become null
			 */
		
			while (chan != null) wait();
			}
	
	public synchronized T receive()
			throws InterruptedException {
			// It waits until a message is ready on the channel,
			// when ready = 1
			while (ready==0) wait();

			/**
			 *  It copies the message, release the channel and
			 *  notifies the senders
			 */
			--ready;
			T tmp = chan; chan = null;
			notifyAll();
		
			return(tmp);
			}
}
