

public class Fork {

	private boolean busy = false; // is used as a condition variable, representing if the thread is busy or free from the lock 
	/**
	 * Instantiate the channel, with a message of type boolean
	 */
	Channel<Boolean> chan = new Channel<Boolean>();
	
	
	public void take() {
		
		
		try {
			while (busy) {
				chan.send(true); // send the message
				}
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		
		busy = true; // the thread will get busy
		
	}

	public void put() {
		
		try {
			chan.receive(); //receive the message
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		busy = false; // when philosopher calls the put() method the message is received and busy becomes false again
 		
	}
	
	/**
	 *  checks the state of the threads, if are in  waiting state or not
	 */
	public boolean isFree() {
		
		return busy;
	}

}
