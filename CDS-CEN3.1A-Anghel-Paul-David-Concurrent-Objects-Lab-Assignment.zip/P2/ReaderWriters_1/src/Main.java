
public class Main {

public static void main(String[] args) throws Exception {
				
		System.out.println("Readers and Writers Problem using semaphores.");
		System.out.println("- More readers can read at the same time the same shared resource as long as\r\n" + 
				"there is no writer with writing access to the same shared resource \n");
				
		/**
		 * Creating 3 Readers and 1 Writer
		 */
		Reader reader_1 = new Reader();
		Reader reader_2 = new Reader();
		Reader reader_3 = new Reader();
		Writer writer = new Writer();
		
		/**
		 * Setting a name to every reader and the writer, for identifying purposes
		 */
		reader_1.setName("Reader 1");	
		reader_2.setName("Reader 2");		
		reader_3.setName("Reader 3");
		writer.setName("WRITER");		
	
		/**
		 * Starting the writer Thread and the Reader Threads
		 */
		writer.start();
		reader_1.start();
		reader_2.start();
		reader_3.start();		
		
	}
}
