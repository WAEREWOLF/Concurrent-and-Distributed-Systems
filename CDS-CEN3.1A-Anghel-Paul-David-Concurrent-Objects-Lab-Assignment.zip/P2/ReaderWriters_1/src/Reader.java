import java.util.concurrent.Semaphore;

public class Reader extends Thread{

	/**
	 * Creating semaphores for readers and writers
	 */
	static Semaphore reader;
	static Semaphore writer;
	/**
	 * Number of processes that performs Reading in the critical section 
	 */
	 static int readersCount;

	Reader() {
		/**
		 * Initializing readers semaphore with 3 permits, because we have multiples readers
		 * and a single writer 
		 */
		reader = new Semaphore(3); 
		writer = new Semaphore(1);
		readersCount = 0; // initial numbers of the readers in the critical section is 0
	}
	/**
	 * This function is called when the Thread Reader starts
	 */
	public void run() {
		
		try {
			/**
			 * Reader wants to enter the critical section
			 */
			reader.acquire();
			readersCount++; // The number of readers is increased by one 
			/**
			 * If there is already a reader in the critical section, then the Writer can't enter CS 
			 */
			if (readersCount == 1) {
				writer.acquire();
			}
			/**
			 * Other Reader threads can enter the critical section while there are already a reader inside  
			 */
			reader.release(); 

			System.out.println(Thread.currentThread().getName() + " is Reading!");
			Thread.sleep(500); //Reader is reading (Thread will sleep for 0.5 s)
			System.out.println(Thread.currentThread().getName() + " has Finished reading!");

			/**
			 * Reader must exit CS
			 */
			reader.acquire();
			readersCount--; // the numbers of readers is decreased because one had left

			/**
			 * If there are no more readers in the critical section, then the Writer thread can enter
			 */
			if (readersCount == 0) {
				writer.release();
			}
			/**
			 * Reader left
			 */
			reader.release();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
