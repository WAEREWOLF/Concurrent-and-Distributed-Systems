import java.util.concurrent.Semaphore;

public class Writer extends Thread{
	/**
	 * Creating semaphores for readers and writers
	 */
	static Semaphore reader; 
	static Semaphore writer;
	/**
	 * Number of processes that performs Reading in the critical section 
	 */
	 static int readersCount;

	Writer(){
		
		/**
		 * Initializing readers semaphore with 3 permits, because we have multiples readers
		 * and a single writer 
		 */
		reader = new Semaphore(3);
		writer = new Semaphore(1);
		readersCount = 0; // initial numbers of the readers in the critical section is 0
	}
	
	/**
	 * This function is called when the Thread Writer starts
	 */
	public void run() {
		try {
			/**
			 * A Writer wants to enter in the critical section 
			 */
			writer.acquire();
			System.out.println(Thread.currentThread().getName() + " is Writing!");
			Thread.sleep(1000); //Writer is writing (Thread sleeps for 1 s)
			System.out.println(Thread.currentThread().getName() + " has finished writing!");
			/**
			 * The Writer leaves the critical section
			 */
			writer.release();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
