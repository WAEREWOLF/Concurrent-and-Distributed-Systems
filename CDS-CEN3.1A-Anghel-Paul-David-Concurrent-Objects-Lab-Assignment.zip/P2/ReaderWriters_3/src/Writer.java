import java.util.concurrent.Semaphore;

public class Writer extends Thread{
	/**
	 * Creating semaphores for readers and writers
	 */
	static Semaphore writer; 
	static Semaphore reader;
	static Semaphore serviceQueue;
	/**
	 * Number of processes that performs Reading in the critical section 
	 */
	 static int readersCount;

	Writer(){
		
		/**
		 * Initializing readers and writers semaphore with 1 permits 
		 */
		writer = new Semaphore(1);
		reader = new Semaphore(2);
		serviceQueue = new Semaphore(1);
		readersCount = 0; // initial numbers of the readers in the critical section is 0
	}
	
	/**
	 * This function is called when the Thread Writer starts
	 */
	public void run() {
		try {
			/**
			 * A Writer wants to enter in the critical section 
			 */
			serviceQueue.acquire();          // wait in line to be serviced
		    writer.acquire();        // request exclusive access to resource
		    serviceQueue.release(); // let next in queue to be serviced
			System.out.println(Thread.currentThread().getName() + " is Writing!");
			Thread.sleep(1000); //Writer is writing (Thread sleeps for 1 s)
			System.out.println(Thread.currentThread().getName() + " has finished writing!");
			/**
			 * The Writer leaves the critical section
			 */
			writer.release();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
