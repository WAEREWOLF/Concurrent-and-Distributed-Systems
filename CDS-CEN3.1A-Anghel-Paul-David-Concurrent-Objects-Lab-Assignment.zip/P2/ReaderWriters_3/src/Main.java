
public class Main {

public static void main(String[] args) throws Exception {
				
		System.out.println("Readers and Writers Problem using semaphores.");
		System.out.println("- There is no starvation for readers or writers"); 
				
		/**
		 * Creating 2 Readers and 1 Writer
		 */
		Reader reader1 = new Reader();
		Reader reader2 = new Reader();
		Writer writer1 = new Writer();
		
		/**
		 * Setting a name to every reader and the writer, for identifying purposes
		 */
		reader1.setName("Reader 1");
		reader2.setName("Reader 2");	
		writer1.setName("WRITER");		
	
		/**
		 * Starting the writer Thread and the Reader Threads
		 */
		reader1.start();
		reader2.start();
		writer1.start();
		
	}
}
