import java.util.concurrent.Semaphore;

public class Reader extends Thread{

	/**
	 * Creating semaphores for readers and writers and also for  Fairness, that preserves ordering of requests
	 */
	static Semaphore writer;
	static Semaphore reader;
	static Semaphore serviceQueue;
	/**
	 * Number of processes that performs Reading in the critical section 
	 */
	  static int readersCount;

	Reader() {
		/**
		 * Initializing readers and writers semaphores
		 */
		writer = new Semaphore(1); 
		reader = new Semaphore(1); 
		serviceQueue = new Semaphore(1);
		readersCount = 0; // initial numbers of the readers in the critical section is 0
	}
	/**
	 * This function is called when the Thread Reader starts
	 */
	public void run() {
		
		try {
			serviceQueue.acquire(); // wait in queue to be serviced
			/**
			 * Reader wants to enter the critical section
			 */
			reader.acquire();
			/**
			 * if there are no readers already reading
			 */
			if (readersCount == 0) {
				writer.acquire(); // writers are blocked
			}
			readersCount++; // The number of readers is increased by one 
			/**
			 * let next in queue to be serviced
			 */
			serviceQueue.release(); 
			/**
			 * Other Reader threads can enter the critical section while there are already a reader inside  
			 */
			reader.release(); 

			System.out.println(Thread.currentThread().getName() + " is Reading!");
			Thread.sleep(500); //Reader is reading (Thread will sleep for 0.5 s)
			System.out.println(Thread.currentThread().getName() + " has Finished reading!");

			/**
			 * Reader must exit CS
			 */
			reader.acquire();
			readersCount--; // the numbers of readers is decreased because one had left

			/**
			 * If there are no more readers in the critical section, then the Writer thread can enter
			 */
			if (readersCount == 0) {
				writer.release();
			}
			/**
			 * Reader left
			 */
			reader.release();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
