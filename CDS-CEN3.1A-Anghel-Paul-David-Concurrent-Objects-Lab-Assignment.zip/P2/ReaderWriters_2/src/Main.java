
public class Main {

public static void main(String[] args) throws Exception {
				
		System.out.println("Readers and Writers Problem using semaphores.");
		System.out.println("- A writer will get exclusive access to the shared resource (no other writer and/or\r\n" + 
							"reader can have access at the same time to the same shared resource) \n");
				
		/**
		 * Creating 1 Reader and 1 Writer
		 */
		Reader reader = new Reader();
		Writer writer1 = new Writer();
		Writer writer2 = new Writer();
		Writer writer3 = new Writer();
		
		/**
		 * Setting a name to every reader and the writer, for identifying purposes
		 */
		reader.setName("Reader");	
		writer1.setName("WRITER 1");
		writer2.setName("WRITER 2");	
		writer3.setName("WRITER 3");	
	
		/**
		 * Starting the writer Thread and the Reader Thread
		 */
		reader.start();
		writer1.start();
		writer2.start();
		writer3.start();
		
	}
}
