import java.util.concurrent.Semaphore;

public class Main {

	/**
	 * Creating the common semaphores for readers and writers, also the counter for active readers in cs, and active writers in cs
	 */
	static Semaphore reader = new Semaphore(1);
	static Semaphore writer = new Semaphore(1);
	
	static int readerCount = 0;
	static int writerCount = 0;
	
public static void main(String[] args) throws Exception {
				
		System.out.println("Readers and Writers Problem using semaphores.");
		System.out.println("-  the constraint is that no writer, once added to the queue, shall be kept waiting longer than absolutely necessary.");
				
		/**
		 * Creating 1 Reader and 1 Writer
		 */
		Reader reader = new Reader();
		Writer writer1 = new Writer();
		Writer writer2 = new Writer();
		Writer writer3 = new Writer();
		
		/**
		 * Setting a name to every reader and the writer, for identifying purposes
		 */
		reader.setName("Reader");	
		writer1.setName("WRITER 1");
		writer2.setName("WRITER 2");	
		writer3.setName("WRITER 3");	
	
		/**
		 * Starting the writer Thread and the Reader Thread
		 */
		writer1.start();
		reader.start();
		writer2.start();
		writer3.start();
		
	}
}
