import java.util.concurrent.Semaphore;

public class Writer extends Thread{
	/**
	 * Creating semaphores for readers and writers
	 */
	static Semaphore reader; 
	static Semaphore writer;
	/**
	 * Number of processes that performs Reading in the critical section 
	 */
	static int writersCount;

	Writer(){
		
		/**
		 * Initializing readers, writer and the active readers with the ones in the main class to be the same semaphores for everyone
		 */
		reader = Main.reader;
		writer = Main.writer;
		writersCount = Main.writerCount; // initial numbers of the readers in the critical section is 0
	}
	
	/**
	 * This function is called when the Thread Writer starts
	 */
	public void run() {
		try {
			/**
			 * A Writer wants to enter in the critical section 
			 */
			writer.acquire();
			writersCount++; // the number of writers is increased
			if(writersCount == 1) {
				reader.acquire(); // if there is already a writer in the critical section, the readers must wait
			}
			writer.release(); // there can be multiple writers that are joining the first writer in the cs
			
			System.out.println(Thread.currentThread().getName() + " is Writing!");
			Thread.sleep(1000); //Writer is writing (Thread sleeps for 1 s)
			System.out.println(Thread.currentThread().getName() + " has finished writing!");
			/**
			 * The Writer leaves the critical section
			 */
			writer.acquire();
			writersCount--; // the numbers of active writers is decreasing 
			
			/**
			 * The last writer will unlock the resource for the readers to access it
			 */
			if (writersCount == 0) {
				reader.release();  
			}
			writer.release();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
