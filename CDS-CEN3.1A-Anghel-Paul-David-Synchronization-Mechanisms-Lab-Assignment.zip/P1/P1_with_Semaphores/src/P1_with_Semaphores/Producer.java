package P1_with_Semaphores;

public class Producer extends Thread{
	private int MAX = 10;	/* The maximum elements that will be produced (added in to the shared list)*/
	PCQueue pcQueue;
	
	public Producer(PCQueue pcQueue ) {
		this.pcQueue = pcQueue;
	}
	public void run() {
		for(int i=0; i<MAX; i++ ) {
			try {
				pcQueue.put(i);			/* Calling the method put(i) from the PcQueue class, that will */	
			}catch(Exception e) {		/* add numbers in to the list of Integers, only if the list is not full yet */
				e.printStackTrace();
			}
			
		}
	}
}
