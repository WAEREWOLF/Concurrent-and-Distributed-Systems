package P1_with_Semaphores;

public class Main {

	public static void main(String args[]) throws InterruptedException {
		
		/**
		 * Instantiate the shared object that will be accessed by the Producer and Consumer objects
		 */
		PCQueue pcQueue = new PCQueue();
		/**
		 * Creating the consumer and producer objects that will share a common resource, pcQueue
		 */
		
		Consumer c = new Consumer(pcQueue);
		Producer p = new Producer(pcQueue);		
		
		/**
		 *  Threads are started and the run() method from The Producer and Consumer class will be called
		 */
		p.start();
		c.start();
		
		
				
	}
}
