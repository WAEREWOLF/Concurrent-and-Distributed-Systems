package P1_with_Semaphores;

public class Consumer extends Thread {
	private int MAX = 10; /* The maximum elements that will be consumed (removed from the shared list) */
	PCQueue pcQueue;
	public Consumer(PCQueue pcQueue ) {
		this.pcQueue = pcQueue;
	}
	public void run() {
		for(int j=0; j<MAX; j++ ) {
			
			try {				
				pcQueue.get();      /* Accessing get() method from the PcQueue class to get the items */
									/* by removing existing integers from the shared list */
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
	}
}
