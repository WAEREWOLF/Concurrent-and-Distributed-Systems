package P1_with_Semaphores;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Semaphore;

public class PCQueue {
	
	/**
	 * Creating 2 semaphores 
	 * semaphores controls access to the shared resource through the use of a counter.
	 * If the counter is greater than zero, then access is allowed, otherwise the access is denied 
	 */
	public static Semaphore semaphore1 = new Semaphore(1);
	public static Semaphore semaphore2 = new Semaphore(1);
	
	private int listSize = 2; /* Maximum limit of elements that can occur in the list at a time*/
	List<Integer> list = new LinkedList<Integer>();
		
	public  void put(int n) {
		
			try {
				while (list.size() == listSize)  /*if the list is full it waits to be consumed by the producer */
												/* (consumer must remove some elements from the list)*/
					semaphore1.acquire();        /* Acquiring the lock */
					
				System.out.println("Producer produced: " + n); /* Display the produced elements*/

				list.add(n); /* Insert in to the list the 'produced elements'*/
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {				
     
				semaphore2.release(); /* Release the lock */
			}
		
			
	}
	public void get() {
		
			try {
				while (list.size() == 0)  /*if the list is empty it waits to be filled by the producer */
					semaphore2.acquire(); /* Acquiring the lock */
				
				System.out.println("Consumer consumed: " + list.remove(0));  /* Remove the first element from the list*/
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
	
				semaphore1.release();  /* Release the lock */
				
			}
				
		
	}
}
