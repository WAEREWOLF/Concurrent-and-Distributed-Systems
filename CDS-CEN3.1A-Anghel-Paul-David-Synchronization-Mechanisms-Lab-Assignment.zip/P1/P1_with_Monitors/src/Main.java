
public class Main {
	
	public static void main(String args[]) throws InterruptedException {
		
		/**
		 * Instantiate the shared object that will be accessed by the Producer and Consumer objects
		 */
		PcQueue pcQueue = new PcQueue();
		/**
		 * Creating the consumer and producer that will share a common resource, pcQueue
		 */
		Consumer c1 = new Consumer(pcQueue);
		Producer p1 = new Producer(pcQueue);
		
		/**
		 * Threads are started and the run() method from The Producer and Consumer class will be called
		 */
		p1.start();
		c1.start();
				
		
	}
	
}
