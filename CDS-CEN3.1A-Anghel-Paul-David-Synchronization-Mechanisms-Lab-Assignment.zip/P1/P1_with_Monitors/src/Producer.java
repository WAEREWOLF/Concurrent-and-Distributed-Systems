
public class Producer extends Thread{
	
	PcQueue pcQueue;
	private int MAX = 10; /* The maximum elements that will be produced (added in to the shared list)*/
	public Producer(PcQueue pcQueue) {
		this.pcQueue = pcQueue;
	}
	
public void run() {
		
		for(int i = 0;i<MAX;i++) { 
			try {
				pcQueue.put(i);   /* Accessing put(int i) method from the PcQueue class to produce the required items*/
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
						
		}
	}

}
