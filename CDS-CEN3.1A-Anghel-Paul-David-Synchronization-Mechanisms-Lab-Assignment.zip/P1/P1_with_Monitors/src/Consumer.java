
public class Consumer extends Thread{
	
	PcQueue pcQueue;
	private int MAX = 10; /* The maximum elements that will be consumed (removed from the shared list)*/
	public Consumer(PcQueue pcQueue) {
		this.pcQueue = pcQueue;
	}
	
public void run() {
		
		for(int i=0; i<MAX;i++) {
			try {
				pcQueue.get();      /* Accessing get() method from the PcQueue class to 'consume' the items*/
										/* by removing existing integers from the shared list*/
			} catch (Exception e) {
				
				e.printStackTrace();
			}
						
		}
	}

}
