import java.util.LinkedList;

public class PcQueue {
	
	/**
	 * Creating a list of integers that will represent the shared resource accessed by the consumer and producer
	 */
	LinkedList<Integer> list = new LinkedList<>(); 
    int capacity = 2; /* the maximum capacity of elements in the list at a time */

    /**
     * This Function is called by Producer thread  
     * Synchronized method is used to lock an object for any shared resource 
     */
    public synchronized void put(int n)  
    { 
                    
                /*
                 *  Producer thread waits while list is full 
                 */                 
                while (list.size() == capacity)
					try {
						wait();          /* forces the current thread to wait until the other thread 
										/* invokes notify() or notifyAll() on the shared object.*/                   
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					} 

                System.out.println("Producer produced " + n); /* Display the elements that the Producer produces*/

                /* insert the 'produced' elements in the list */ 
                list.add(n); 

                /*
                 * Will notify the consumer that it can start to consume (remove elements from the list)
                 */
                notifyAll();

    } 

    /*
     * This Function is called by Consumer thread,
     * Synchronized method is used to lock an object for any shared resource 
     */
    public synchronized void get() 
    { 
    	/**
    	 *  Consumer thread waits while list is empty
    	 */
                
                while (list.size() == 0)
					try {
						wait();    /* forces the current thread to wait until the other thread 
									/* invokes notify() or notifyAll() on the shared object.*/
					} catch (InterruptedException e) {
						
						e.printStackTrace();
					} 

                /* remove the first element form the list */ 
                int value = list.removeFirst(); 

                System.out.println("Consumer consumed-"+ value); 

                /*  Wake up the Producer thread to produce more 'products' */
                notifyAll(); 
                
      
}
}
