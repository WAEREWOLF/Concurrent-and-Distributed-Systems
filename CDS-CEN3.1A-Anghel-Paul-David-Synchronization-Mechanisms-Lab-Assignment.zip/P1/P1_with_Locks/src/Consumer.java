
public class Consumer extends Thread{
	private int MAX = 10; /* Maximum numbers that will be consumed by the Consumer*/
	PcQueue sharedQueue;
	/**
	 * The Consumer receive the common resource through its constructor, sharedQueue
	 */
    public Consumer(PcQueue sharedQueue) {
        this.sharedQueue = sharedQueue;
     }
   
    /**
     * This method is called when the thread start
     */
    public void run() {
        for (int i = 1; i <= MAX; i++) {   /*consume MAX products.*/
         try {
           sharedQueue.consume(); /* Calling the method consume from the PcQueue class, that will */
         } catch (Exception e){    /* remove numbers from the list, only if the list is not empty yet*/  
        	 e.printStackTrace();   
        	 }
        }
           
    }   
   
}
