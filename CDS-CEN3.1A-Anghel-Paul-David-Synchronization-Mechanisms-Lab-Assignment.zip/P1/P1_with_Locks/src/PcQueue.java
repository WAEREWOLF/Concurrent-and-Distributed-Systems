import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class PcQueue {
	
	/**
	 * Creating a list of Integers that represents the shared resource
	 */
	List<Integer> sharedQueue = new LinkedList<Integer>(); 
	private int maxSize = 2; /*maximum number of products that can be stored in the list*/
	/**
	 * Creating the lock that will provide synchronization to methods while accessing shared resources
	 */
	   Lock lock = new ReentrantLock(); 
	   
	   /* ProducerCondition */
	   Condition producerCondition = lock.newCondition();
	   
	   /* ConsumerCondition */
	   Condition consumerCondition = lock.newCondition();
	   
	   /**
	    * Method that will make sure to add items in to the list until it becomes full
	    */
	   public void produce(int i) {
           lock.lock(); /* Acquires the lock. */
 
           /**
            *  if sharedQueue is full producer await until consumer consumes.
            */
           if (sharedQueue.size() == maxSize) {
                  try {
					producerCondition.await();
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
           }
 
           System.out.println("Produced : " + i);
           /**
            *  As soon as producer added items in sharedQueue it will signal the consumer.
            */
           sharedQueue.add(i);
           consumerCondition.signal();

           lock.unlock(); /* Releases the lock. */
 
    }
	   
	   /**
	    * Method that will make sure to remove items from the list if is not empty yet
	    */
	   
	   public void consume() {
           lock.lock(); /* Acquires the lock. */
 
           // if sharedQuey is empty consumer await until producer produces.
           if (sharedQueue.size() == 0) {
                  try {
					consumerCondition.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
           }
 
 
     /**	If sharedQueue not empty consumer will consume,
      * by removing from sharedQueue and will signal the producer.
      */
           System.out.println("CONSUMED: " + ((LinkedList<Integer>) sharedQueue).removeFirst());
           producerCondition.signal();

           lock.unlock(); /* Releases the lock. */
 
    }
}
