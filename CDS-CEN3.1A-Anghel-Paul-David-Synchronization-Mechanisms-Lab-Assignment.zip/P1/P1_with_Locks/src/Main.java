

public class Main {
	 public static void main(String[] args) {
       
/**
 * Instantiate the shared object that will be accessed by the Producer and Consumer objects
 */
     PcQueue sharedQueue = new PcQueue();
     
/**
 * Instantiate objects of type Producer and Consumer that receive by parameter the shared resource sharedQueue
 */
     Producer producer=new Producer(sharedQueue);
     Consumer consumer=new Consumer(sharedQueue);
     
/**
 * Producer and Consumer class are extending Thread, so the 2 instantiated threads are started          
 */
      producer.start();
      consumer.start();      
      
         
  }
}
