
public class Producer extends Thread{
	PcQueue sharedQueue;    
   private int MAX = 10; /* Maximum numbers that will be produced by the Producer*/
	/**
	 * The Consumer receive the common resource through its constructor, sharedQueue
	 */
    public Producer(PcQueue sharedQueue) {
        this.sharedQueue = sharedQueue;
        
    } 
    
    /**
     * This method is called when the thread start
     */
    public void run() {
        for (int i = 1; i <= MAX; i++) {  //produce products.
         try {
           sharedQueue.produce(i); /* Calling the method produce from the PcQueue class, that will */
         } catch (Exception e) {  /* add numbers in to the list of Integers, only if the list is not full yet */ 
        	 e.printStackTrace();   
        	 }
        }
    } 
 
}
