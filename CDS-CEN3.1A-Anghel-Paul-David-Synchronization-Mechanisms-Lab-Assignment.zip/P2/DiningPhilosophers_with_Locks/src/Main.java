
public class Main {
	
	/**
	 * @param philosophersNumber represents the maximum numbers of the philosophers
	 * @param forks[] is a vector of type fork that represents all the forks created that has the size of the philosophers
	 */
	static int philosophersNumber = 5;
	static Philosopher philosophers[] = new Philosopher[philosophersNumber];
	static Fork forks[] = new Fork[philosophersNumber];
	

	public static void main(String argv[]) {
		
		/**
		 * creating forks and put them in the vector until the number of philosophers is reached 
		 */
		for (int i = 0; i < philosophersNumber; i++) {
			forks[i] = new Fork();
		}
/**
 * creating the philosophers objects that receives through constructor a number, a left fork, and a right fork
 */
		for (int i = 0; i < philosophersNumber; i++) {
			philosophers[i] = new Philosopher(i, forks[i], forks[(i + 1) % philosophersNumber]);
			philosophers[i].start(); // philosopher thread is started and the run() method is called
		}

		while (true) {
			try {
				//Thread will  sleep 1 sec
				Thread.sleep(1000);

				/**
				 *  Deadlock must be avoided and signal it when appears
				 */
				boolean deadlock = true;
				for (Fork f : forks) {
					if (f.isFree()) {      // checks if is out of the lock
						deadlock = false;  // then is not possible a deadlock
						break;
					}
				}
				if (deadlock) {  //describes a situation where two or more threads are blocked forever, waiting for each other
					Thread.sleep(1000);
					System.out.println("Deadlock!");  // when the deadlock appears the program exits
					break; 
				}
			} catch (Exception e) {
				e.printStackTrace(System.out);
			}
		}

		System.out.println("STOP");
		System.exit(0);
	}
}
