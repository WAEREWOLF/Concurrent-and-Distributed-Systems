import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Fork {

	private boolean busy = false; // is used as a condition variable, representing if the thread is busy or free from the lock 
	ReentrantLock lock = new ReentrantLock(); // initializing the lock
	
	/**
	 * creating a condition that will provides a thread with the ability to suspend its execution, until the condition is true.
	 * and is bounded by the lock
	 */
	Condition condition = lock.newCondition(); 
	
	public void take() {
		
		lock.lock(); // acquires the lock
		try {
			if (busy)
				condition.await();
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		busy = true; // the lock is locked so the thread will get busy
		
	}

	public void put() {
		
		busy = false; // when philosopher calls the put() method the lock is released and busy becomes false again
 		condition.signalAll(); // wakes up all the waiting threads (philosophers)
		lock.unlock(); // releases the lock
	}
	
	/**
	 * checks the state of the lock, and if is free, acquires the lock 	 * 
	 */
	public boolean isFree() {
		
		return lock.tryLock();
	}

}
