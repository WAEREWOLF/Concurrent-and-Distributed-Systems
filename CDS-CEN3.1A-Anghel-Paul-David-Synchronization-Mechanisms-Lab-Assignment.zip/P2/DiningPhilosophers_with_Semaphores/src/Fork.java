import java.util.concurrent.Semaphore;

public class Fork {
/*
 * creating the semaphore
 */
	public Semaphore semaphore;

	Fork() {

		semaphore = new Semaphore(1); //initialize the semaphore with the permits 1
	}

	void take() {
		try {
			semaphore.acquire(); /* Acquiring the lock */
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	void put() {
		semaphore.release();   /* Releasing the lock */
	}

	boolean isFree() {
		return semaphore.availablePermits() > 0; //Returns the current number of permits available in the semaphore
	}

}
