
public class Main {
	
	static int philosophersNumber = 5;
	static Philosopher philosophers[] = new Philosopher[philosophersNumber];
	static Fork forks[] = new Fork[philosophersNumber];
	/**
	 *  philosophersNumber represents the maximum numbers of the philosophers
	 *  forks[] is a vector of type fork that represents all the forks created that has the size of the philosophers
	 */

	public static void main(String argv[]) {
		/**
		 * creating forks and put them in the vector until the number of philosophers is reached 
		 */
		for (int i = 0; i < philosophersNumber; i++) {
			forks[i] = new Fork();
		}
		/**
		 * creating the philosophers objects that receives through constructor a number, a left fork, and a right fork
		 */
		for (int i = 0; i < philosophersNumber; i++) {
			philosophers[i] = new Philosopher(i, forks[i], forks[(i + 1) % philosophersNumber]);
			philosophers[i].start();
		}

		while (true) {
			try {
				// Thread sleep 1 sec
				Thread.sleep(1000);

				// check for deadlock
				boolean deadlock = true;
				for (Fork f : forks) {
					if (f.isFree()) {
						deadlock = false;
						break;
					}
				}
				if (deadlock) {  // represents situation where two or more threads are blocked forever, waiting for each other
					Thread.sleep(1000);
					System.out.println("Deadlock!");
					break;
				}
			} catch (Exception e) {
				e.printStackTrace(System.out);
			}
		}

		System.out.println("STOP");
		System.exit(0);
	}
}
