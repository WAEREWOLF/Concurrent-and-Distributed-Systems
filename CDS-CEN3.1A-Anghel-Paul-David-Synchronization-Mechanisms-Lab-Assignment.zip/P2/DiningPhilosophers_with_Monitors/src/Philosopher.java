import java.util.concurrent.ThreadLocalRandom;

public class Philosopher extends Thread{
	public int number;
	public Fork leftFork;
	public Fork rightFork;
	/**
	 * 
	 * @param number - each philosopher is identified by a number
	 * @param leftFork - each philosopher can have a left fork
	 * @param rightFork - each philosopher can have a left fork 
	 */
	public Philosopher(int number, Fork leftFork, Fork rightFork) {
		
		this.number = number;
		this.leftFork = leftFork;
		this.rightFork = rightFork;
	}
	/**
	 *  This method is called when the thread starts
	 */
	public void run() {
		
		System.out.println("Philosopher " + number); //each philosopher is identified by a number
		while(true) {
			
			leftFork.take();
			System.out.println("Philosopher "+ number + " takes left fork");
			rightFork.take();
			System.out.println("Philosopher "+ number + " takes right fork");
			eat(); // when the philosopher has the 2 forks lifted at a time, then he can eat
			leftFork.put();
			System.out.println("Philosopher "+ number + " puts down left fork");
			rightFork.put();
			System.out.println("Philosopher "+ number + " puts down right fork");
			
		}
	}
	/*
	 * Just printing the number of the philosopher that is currently eating, and the thread sleeps for a random period of time
	 */
	void eat() {
		try {
			int sleep = ThreadLocalRandom.current().nextInt(0, 1000);
			System.out.println("\nPhilosopher #"+number + " eats for " + sleep+"\n");
			Thread.sleep(sleep);
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}
	
}
