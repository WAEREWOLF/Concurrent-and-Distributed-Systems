
public class Fork {
	
	private boolean busy = false;

	Fork() {
		
	}
/**
 * Synchronized blocks  on the same object can only have one thread executing inside them at a time.
 */
	synchronized void take() {
		try {
			while(busy)
				wait();   		/* forces the current thread to wait until the other thread 
									/* invokes notify() or notifyAll() on the shared object.*/  
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
		busy = true;
	}

	synchronized void put() {
		busy = false; // the put() method was called, so the monitor is free
		notifyAll(); // wakes the waiting threads
	}
	
	boolean isFree() {
		return busy;  // checks the state of the threads, if are in  waiting state or not
		
	}
}
