import java.util.concurrent.TimeUnit;

public class RetireDemons extends Thread{
	
	private Demon[] Demons;
	
	public RetireDemons(Demon[] demon) {
		this.Demons = demon;
	}
	
   public void run() {
	   
	 while(true) {
		 if(Demons != null) {
		// Demon.semaphoreDemon.release();
	
		       for(int i = 0; i< 2;i++) {
				   Demons[i].interrupt(); /** trying to interrupt the demon threads in order to be retired*/
			   }
			   System.out.println("\t2 demons retired!");
		
			   try {
				sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
	}
	 // Demon.semaphoreDemon.release();
	 }
	 //System.out.println("null");
}
	


