import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;

public class Undead extends Thread{
	
	private int undeadNumber;
	private int randRetiredDemons;
	private Demon[] Demons;
	private ConcurrentLinkedQueue<Integer> PotionsQueue;
	MainSorcererCircle main = new MainSorcererCircle();
	/**initialize the constructor with an ID for every Undead, the queue where he will put the ingredients for the witches, and the array with 
	* Demon threads in order to retire demons */
	Undead(int undeadNumber, ConcurrentLinkedQueue<Integer> PotionsQueue, Demon[] Demons){
		
		this.undeadNumber = undeadNumber;
		this.PotionsQueue = PotionsQueue;
		this.Demons = Demons;
		randRetiredDemons = ThreadLocalRandom.current().nextInt(5,10);
	}
	/** function that will steal all the current ingredients from the queue*/
	private void stealPotions() {	
		      
	       /** The queue with the ingredients must not be empty in order to steal*/ 
	        if (!PotionsQueue.isEmpty()){
	        	System.out.println("Ingredients list: "+PotionsQueue);
	        	/** Iterate through the queue and remove every ingredient */
	        	for(Integer i : PotionsQueue) {
	        		PotionsQueue.remove(i);
	        		
	        	}
	        	System.out.println("\tUNDEAD "+this.undeadNumber+" stealed the ingredients now are "+ PotionsQueue);
	        	
	        } 
	       // else System.out.println("UNDEAD "+this.undeadNumber + " Has NOTHING to steal"); 
	}

	/** function that is called to retire some Demon threads*/
private void retireDemons() {
	
	/** The array with Demon threads shouldn't be empty*/
	if(Demons != null) {
		
	  if(randRetiredDemons <= Demons.length) { /** the random number must be less then the actual number of Demon threads to avoid the null exception*/
		
		for(int i = 0; i<randRetiredDemons;i++) {
			
			Demons[i].stopDemon(); /** every chosen threads will call the interrupt method the Demon class that will interrupt it's running method*/
			}
		System.out.println(randRetiredDemons +" demons are retired by UNDEAD "+ this.undeadNumber);
			
	  	}			
	}
		try {
			sleep(2000); //sleeps for 2s
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  
}


	
    public void run(){

    	try {
			sleep(3000); // delay is waking 
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        while (true){
            try {
            	stealPotions(); /**call the methods and then go to sleep for a random period of time */
            	retireDemons();
            	
            	sleep(ThreadLocalRandom.current().nextInt(2000,3000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
