import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;

public class MainSorcererCircle extends Thread{

	/** Create the numbers of covens, demons, witches and undeads*/
	private int covensCount;
	private int demonsCount;
	private int witchesCount;
	private int undeadsCount;
	private Coven[] Covens; /** An array with all the Coven threads */
    private Demon[] Demons; /** An array with all the Demon threads*/
    private Witch[] Witches; /** An array with all the Witch threads*/
    private Undead[] Undead;  /** An array with all the Undead threads*/
    private Sorcerer sorcerer; // an instance of the Sorcerer class in order to start its thread
    private RetireDemons retDemons; // an instance of the RetireDemons class in order to start its thread
    // potions queue 
    private ConcurrentLinkedQueue<Integer> PotionsQueue;
    /**Built-in concurrent queue,used for communication between witches and the Sorcerer*/
    private ConcurrentLinkedQueue<String> SorcererQueue;
    
    MainSorcererCircle(){
    	/**Initialize variables with random values in a given range
    	 */
        covensCount = ThreadLocalRandom.current().nextInt(3,20);
        demonsCount = ThreadLocalRandom.current().nextInt(3,Coven.arraySize/2);
        witchesCount = ThreadLocalRandom.current().nextInt(3,10);
        undeadsCount = ThreadLocalRandom.current().nextInt(20, 50);
        
        PotionsQueue = new ConcurrentLinkedQueue<Integer>(); // initialize an integer queue for the ingredients (are random numbers)
        SorcererQueue = new ConcurrentLinkedQueue<String>(); // initialize a String queue for potions, because there will be the names of the potion as String

        sorcerer = new Sorcerer(SorcererQueue);
        retDemons = new RetireDemons(Demons);
    }
    
    /** create covens of size of the covens generated random number */
    private void CreateCovens(int covensCount){

        Covens = new Coven[covensCount]; // initialize the Covens array with the size of the random number for covens

        for (int i = 0; i < covensCount; i++){
            Covens[i] = new Coven(); // fill the Covens array with the instances of class Coven
        }
    }


    /**Create and assign a number of demons to a given coven, with a random time between them*/
    private void CreateDemons(int demonsCount, int covenNumber){

        Demons = new Demon[demonsCount]; // initialize the Demons array with the size of the random number for demons

        for (int i = 0; i < demonsCount; i++){
            Demons[i] = new Demon(covenNumber,i,Covens[covenNumber],PotionsQueue); // creates all the demon Threads in the array
            System.out.println("In Coven "+covenNumber+" DEMON " + i + " has SPAWNED!"); // signal that a demon is spawned in a specified coven
            Demons[i].start(); /** starts all the Demon threads*/
            
            try {
            	/** Sleep for a random period of time*/
                Thread.sleep(ThreadLocalRandom.current().nextInt(500,1000));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }    	
    
    }
    

    /**Create and start witches threads*/
    public void CreateWitches(){

        Witches = new Witch[witchesCount]; // initialize the Demons array with the size of the random number for demons

        for (int i = 0; i < witchesCount; i++){ 
            Witches[i] = new Witch(i,PotionsQueue,SorcererQueue); //Creates all the requested number of Witch threads in to the Witches array
            Witches[i].start(); /** start all the Witch threads*/
        }
    }
    /**Create and start undeads threads*/
    public void CreateUndeads(){

        Undead = new Undead[undeadsCount]; // initialize the Undead array with the size of the random number for undeads

        for (int i = 0; i < undeadsCount; i++){
            Undead[i] = new Undead(i,PotionsQueue,Demons); // create Undead threads in the array
            Undead[i].start(); /** starts all the thread in the array of Undead threads*/
        }
    }
    
    

    public void run(){
/**Display at beginning all the random generated numbers for every present element*/
        System.out.println("Covens created: "+this.covensCount+"| A coven size: "+ Coven.arraySize+" | Demons per Coven: "+this.demonsCount+ " | Witches: "+this.witchesCount+"| Undeads: "+ undeadsCount+"\n\n");
        try {
        	
            sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
/**Call the methods in order to start the threads for the Covens, Witches, Demons, Sorcerer and Undeads */
        CreateCovens(covensCount);               
        CreateWitches();
        sorcerer.start(); 
        CreateUndeads();        
        /**create demons threads and start them*/
        for(int i = 0; i < covensCount; i++)
           	CreateDemons(demonsCount,i);
        retDemons.start(); // start the retire Demons thread
    }             
    
    
    public static void main(String[] args) {

    	// make an instance of this class 
        new MainSorcererCircle().start();
    }

}
