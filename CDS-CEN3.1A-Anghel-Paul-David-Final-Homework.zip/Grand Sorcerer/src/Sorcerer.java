import java.util.concurrent.ConcurrentLinkedQueue;

public class Sorcerer extends Thread{
	
/** a thread safe queue for receiving the potions*/
	private ConcurrentLinkedQueue<String> sorcererQueue;
	/** Initialize the sorcerer constructor with the queue*/
	Sorcerer(ConcurrentLinkedQueue<String> SorcererQueue){

        this.sorcererQueue = SorcererQueue;
    }
	
	/** This method is called when the thread starts*/
	public void run() {
		
	while(true) {
		 try {
             Thread.sleep(2000); // sleeps for 2s
         } catch (InterruptedException e) {
             e.printStackTrace();
         }
		 System.out.println("\n\tGRAND SORCERER potions arsenal: "+ sorcererQueue + "\n"); /** display the list with the potions */
	   }
	}
}
