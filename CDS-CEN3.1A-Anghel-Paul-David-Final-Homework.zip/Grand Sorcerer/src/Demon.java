import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadLocalRandom;

public class Demon extends Thread{
	
	 private Coven coven;
	 private int covenNumber;
	 private int demonNumber;
	 private int rowPos, columnPos;
	 boolean flag;
	 boolean increasedSkill = false; /** A demon can increase its social skill by meeting another demon*/
	 private ConcurrentLinkedQueue<Integer> PotionsQueue; /** The thread safe queue for the ingredients*/
	private int socialSkill = 0;  /** Social skill starts with 0 and is incresead by 50 when he run into another demon*/
	//public static Semaphore semaphoreDemon = new Semaphore(0);
	 /**Initialize the demon constructor*/
	 Demon(int covenNumber, int demonNumber, Coven coven ,ConcurrentLinkedQueue<Integer> PotionsQueue){
		 
		 this.covenNumber = covenNumber;
		 this.demonNumber = demonNumber;
		 this.coven = coven;
		 this.PotionsQueue = PotionsQueue;
		
		
	 }
	 	 
	 // generate a position in the array for a Demon
	 public void spawnDemon() {
		 
		 while (coven.getValue(rowPos,columnPos) != 0){
			 this.rowPos = ThreadLocalRandom.current().nextInt(0,Coven.arraySize); /** generate a random number for the rows*/
		     this.columnPos = ThreadLocalRandom.current().nextInt(0,Coven.arraySize); /** generate a random number for the columns*/
	        }

	        coven.setValue(rowPos,columnPos,1);	 // when the demon is in the coven, its cell is marked with 1        
	 }
	 /** set 1 where is a demon and 0 where  is free and update the cells 
	  * will return true if he moved and false if he didn't*/
	 public boolean updateDemonLocation(){

	        int addPos[] = coven.demonNextPos(this.rowPos,this.columnPos);
	        int addRowPos = addPos[0];
	        int addColumnPos = addPos[1];

	        if(addRowPos == 0 && addColumnPos == 0){

	            socialSkill  += 50; 
	            System.out.println("In Coven "+this.covenNumber+" Demon " + this.demonNumber + " HAS NO MOVES!..." + "social skill increased to " + socialSkill);
	            if(socialSkill >= 100) {
	            	increasedSkill = true;
	            }
	            return false;
	        }
	        else {

	            coven.setValue(rowPos,columnPos,0); // set back to 0 his last position
	            rowPos += addRowPos; 
	            columnPos += addColumnPos;
	            coven.setValue(rowPos,columnPos,1); // set the value 1 on its current postion in the array
	        }
	        return true;
	    }
	 //sleep after created an ingredient
	 private int createdIngredient(){

	        try {	           
	            sleep(30);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	        return ThreadLocalRandom.current().nextInt(1,50);
	    }
	 /** Will interrupt the run() method of the current thread and will stop in order to retire a demon*/
	 public void stopDemon() {
		 Thread.currentThread().interrupt();
	 }
	 /** This method is called when the thread starts*/
	 public void run(){
		
	        this.spawnDemon(); 
	        
	        while (true) {
	        		//Check if the demon moved . If true create an ingredient and sleep for a while
					if(updateDemonLocation()){
						
					    int ingredient = createdIngredient();
					    if(increasedSkill) { /** if the current Demon has the increased skill he can add its ingredient twice, as a super power*/
					    	PotionsQueue.offer(ingredient);
					        PotionsQueue.offer(ingredient);
					        System.out.println("In Coven "+this.covenNumber+" Demon "+this.demonNumber+" created ingredient "+ingredient + "Counted twice because is 100 at social skill!");
					     } 
					    else{
					    	PotionsQueue.offer(ingredient); // else just add one ingredient to the queue
					        System.out.println("In Coven "+this.covenNumber+" Demon "+this.demonNumber+" created ingredient "+ingredient);
					    }
					}
					//Otherwise sleep for a random amount of time  [10-50]
					else {
					    try {
					        Thread.sleep(ThreadLocalRandom.current().nextInt(10,50));
					    } catch (InterruptedException e) {
					        e.printStackTrace();
					    }
					}
				
	            try {
	                sleep(2000);
	                
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	            
	            
        }
	       	           	
	        
	        
    }
}
