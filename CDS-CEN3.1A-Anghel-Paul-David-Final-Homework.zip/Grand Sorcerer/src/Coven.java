import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.locks.ReentrantLock;

public class Coven {
	 /** Initialize the size of the array with a random integer*/   
	public static int arraySize = ThreadLocalRandom.current().nextInt(100,500);
	/** The array representing the coven size where the demons will work*/
    private int[][] array;
    /**A lock that will make sure that not the same demon will access the same methods.*/
    private ReentrantLock lock = new ReentrantLock(true);

    Coven(){    	
/** The array is initialized with the random number that will represent the size of the coven between [100, 500]*/
        this.array = new int[arraySize][arraySize];       
    }

   
    /**Set a given value to a position. If the index is not valid throw an exception*/
    public void setValue(int row, int column, int value){
    	/**checks if the given row and column are in the array size bounds*/
        if(row < 0 || row >= arraySize || column < 0 || column >= arraySize){
            throw new ArrayIndexOutOfBoundsException("INVALID position!");
        }else {

            lock.lock(); //acquire the lock
            try {
                array[row][column] = value; //set the value at wanted postion
            }finally {
                lock.unlock(); //release the lock
            }
        }
    }

	/** function that will retrieve a value from a postion*/
    public int getValue(int row, int column){
    	/**checks if the given row and column are in the array size bounds*/
        if(row < 0 || row >= arraySize || column < 0 || column >= arraySize){
            throw new ArrayIndexOutOfBoundsException("INVALID position!");
        }else {

            lock.lock(); // locks in the resource
            try {
                return array[row][column]; //returns the value at the specified position
            }finally {
                lock.unlock(); // the resource is released
            }
        }
    }
    
  
    /**Calculate the next available position that a demon can make */
    public  int[] demonNextPos(int row, int column){

        /**will return true if the demon can go in the wanted direction, meaning that the cell is free, 
         * Position[0] = Up , Position[1] = Down, Position[2] = Left, Position[3] = Right*/
        boolean Positon[] = new boolean[4];
        /**All possible positions are occupied*/
        boolean AllOccupied = true;
        /**Stores the NextRandom Position of a demon, where 
         * nextIndex[0] means that will add to rowIndex, nextIndex[1] will add to columnIndex*/
        int[] nextIndex = new int[2];
        /**Choose a random number between [0-4)*/
        int RandNextPos = ThreadLocalRandom.current().nextInt(0,4);

        lock.lock(); // acquire  the lock

        try {
            //It is checked if the surrounding positions are free
            if(row > 0){ /**must be an available row above the current location of the demon*/ 
                if (array[row-1][column] == 0){         /** in order to move UP on the row, then the row will decrease by one unit*/     
                    Positon[0] = true;  //UP movement true
                }
            }
            if(row < arraySize-1) {  				/** on the row the demon should'nt be at the bottom to be able to increase the row index*/
                if (array[row + 1][column] == 0) {                   
                    Positon[1] = true;   // DOWN movement true
                }
            } 
            if(column > 0) {						/** check if is not at the left border, so the columns index must be greater then 0*/
                if (array[row][column - 1] == 0) {        /** decreases the columns in order to move to the left side */            
                    Positon[2] = true;      //LEFT movement true
                }
            }
            if(column < arraySize-1){			/** in order to move right he checks if there is available a cell in his right, so didnt reached the end of the array */
                if (array[row][column+1] == 0){      /** increase the columns to move right in the array*/            
                    Positon[3] = true; //RIGHT movement true (possible)
                }
            }

            //If there are no free position will return nextPosition = {0,0}
            for (int i = 0; i < 4; i++){
                if(Positon[i] == true){
                    AllOccupied = false;
                }
            }
            if(AllOccupied){
                nextIndex[0] = nextIndex[1] = 0;
                return nextIndex;
            }

            // Choose a valid random position and update the nextPosition array
            else {

            while (!Positon[RandNextPos]){
                  RandNextPos = ThreadLocalRandom.current().nextInt(0,4);
           }
            /** The next direction is chosen by the random number*/
           switch (RandNextPos){
               case 0 :
               //up 
               nextIndex[0] = -1;
               nextIndex[1] = 0;
               break;

               case 1:
               //down
                nextIndex[0] = 1;
                nextIndex[1] = 0;
                break;

               case 2:
               //left
               nextIndex[0] = 0;
               nextIndex[1] = -1;
               break;
               case 3:
               //right
               nextIndex[0] = 0;
               nextIndex[1] = 1;
               break;
                }
            }
        }finally {
            // release the lock
            lock.unlock();
        }
        return nextIndex;
    }	

}
