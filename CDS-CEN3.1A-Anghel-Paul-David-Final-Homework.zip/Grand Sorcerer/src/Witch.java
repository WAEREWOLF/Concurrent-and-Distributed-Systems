import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadLocalRandom;

public class Witch extends Thread{

	private int witchNumber;
	private int ingredientsCount = 0;
	private int neededNumOfIngredients;
	private int randPotion;
	/**  creating the local queues that will be filled through the constructor*/
	private ConcurrentLinkedQueue<Integer> PotionsQueue;
	private ConcurrentLinkedQueue<String> SorcererQueue;
	Semaphore witchSemaphore = new Semaphore(1);	
	//list with possible potions to make, 20 in total
	String potionsType[] = {"STRENGTH", "POWER", "VISION", "CONTROL", "DEATH", "SUN", "EARTH", "AIR", "WATER", "FIRE",
							"WHITE", "BLUE", "RED", "MAGENTA", "ORANGE", "VIOLET", "FLYING", "INVISIBILITY", "IMUNITY", "JUMP"};
	/** receives through parameter the id for every witch, the queue for ingredients and the queue with potions for the Sorcerer*/
	Witch(int witchNumber, ConcurrentLinkedQueue<Integer> PotionsQueue, ConcurrentLinkedQueue<String> SorcererQueue){
		
		this.witchNumber = witchNumber;	
		this.PotionsQueue = PotionsQueue;
		this.SorcererQueue = SorcererQueue;
		/** obtain a random number between [4,8] that will be the needed number of ingredients in order to make a potion*/
		neededNumOfIngredients = ThreadLocalRandom.current().nextInt(4,8);
		randPotion = ThreadLocalRandom.current().nextInt(0,19); //extract a random potion from the potions list
	}
/** function that will take ingredients from the demons queue and make potions, then send it to the Sorcerer in his Queue*/	
	   private void sendPotions(){

	        Integer potions = null;

	        //Pick ingredient from the demons
	        try {
	        if (!PotionsQueue.isEmpty()){ /** Potion queue should not be empty*/
	        	witchSemaphore.acquire(); //acquire the semaphore on the queue
	        	potions = PotionsQueue.poll(); // extract the head element of the queue
	        	ingredientsCount++; // increase the number of ingredients of the current witch
	            System.out.println("Witch "+this.witchNumber+" take ingredient "+potions + " she has " + ingredientsCount + "/"+ neededNumOfIngredients+" ingredients for a potion!");
	        }
	        witchSemaphore.release(); // release the semaphore
	        }catch(Exception e) {
	        	e.printStackTrace();
	        }
	        //Transfer potions to the Sorcerer if has enough ingredients to make them
	       
	        	if(ingredientsCount >= neededNumOfIngredients) { 
	        		SorcererQueue.offer(potionsType[randPotion]); /** insert in the sorcerer queue a random potion*/
	        		ingredientsCount -= neededNumOfIngredients; /** decrease the number of ingredient she has because she just used them*/
	            	System.out.println("Witch "+this.witchNumber+" SENT potion of "+potionsType[randPotion]+" to the Sorcerer... ");
	        		
	        	}
	        
	    }
// this method is called when the thread starts
	    public void run(){

	        while (true){
	            try {
	            	sendPotions(); /** call method and then sleeps for a random period of time*/
	            	
	                sleep(ThreadLocalRandom.current().nextInt(500,1000));
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }
}
