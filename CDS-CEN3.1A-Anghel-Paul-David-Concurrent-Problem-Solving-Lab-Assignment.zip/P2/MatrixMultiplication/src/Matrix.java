import java.util.Arrays;

class Matrix {
	
	/**
	 * @param dim - is the array size
	 * @param data - an array with the matrix elements
	 * @param rowDisplace - the displace on rows of the up left elements
	 * @param colDisplace - the displace on columns of the up left elements
	 */
	int dim;
	double[][] data;
	int rowDisplace, colDisplace;
	
	/**
	 * 
	 * @param d - initialized with array size
	 */
	Matrix(int d) {
		dim = d;
		rowDisplace = colDisplace = 0;
		data = new double[d][d];
	}
	
	/** Print matrix more convenient*/
    public void show() {
    	
    	System.out.println(Arrays.deepToString(data).replace("], ", "]\n"));
    }
	
    /**
     * 
     * @param N - the array size
     * @return a created matrix with the values on the principal diagonal 1
     */
    public static Matrix create(int N) {
        Matrix mat = new Matrix(N);
        for (int i = 0; i < N; i++)
            mat.data[i][i] = 1;
        return mat;
    }
    
       
   /**
    * A second constructor for Matrix objects
    * @param matrix - matrix that is given through constructor, when an instance of type Matrix is created
    * @param x - represents the row
    * @param y - represents the column
    * @param d - is the dimension of the matrix
    */
	Matrix(double[][] matrix, int x, int y, int d) {
		data = matrix;
		rowDisplace = x; colDisplace = y;
		dim = d;
	}
	
	/**
	 * 
	 * @param row - is the row where will get the data
	 * @param col -  represents the column where will get the data
	 * @return value from given position and displacements
	 */
	double get(int row, int col) {
		return data[row+rowDisplace][col+colDisplace];
	}

	
	/**
	 * 
	 * @param row - the row where a value is set
	 * @param col - the column where a value is set
	 * @param value - the value that is required to be set up
	 */
	void set(int row, int col, double value) {
		data[row+rowDisplace][col+colDisplace] = value;
	}
	/** Function that returns the array size (getter for dimension)*/
	int getDim() { 
		return dim; 
	}
	
	/**
	 * 
	 * @return the result of splitting the matrix in 4 submatrices with equal dimensions
	 */
	Matrix[][] split() {
		Matrix[][] result = new Matrix[2][2];
		int newDim = dim / 2;
		result[0][0] = new Matrix(data, rowDisplace, colDisplace,
				newDim);
		result[0][1] = new Matrix(data, rowDisplace,
				colDisplace + newDim, newDim);
		result[1][0] = new Matrix(data, rowDisplace + newDim,
				colDisplace, newDim);
		result[1][1] = new Matrix(data, rowDisplace + newDim,
				colDisplace + newDim, newDim);
		return result;
	}
}
