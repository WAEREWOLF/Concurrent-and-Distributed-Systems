
import java.util.concurrent.*;
public class MatrixTask {	
	/**
	 * Creates a thread pool that creates new threads as needed
	 */
	static ExecutorService exec = Executors.newCachedThreadPool();

	/**
	 * 
	 * @param a - represents the first matrix for multiplication
	 * @param b - represents the second matrix for multiplication
	 * @return - the output matrix c that is the results of b x c
	 * @throws InterruptedException - exceptions if  thread is waiting, sleeping, or otherwise occupied
	 * and the thread is interrupted
	 * @throws ExecutionException -  occurs when attempting to retrieve the result of a task that aborted 
	 * by throwing an exception
	 */
	static Matrix add(Matrix a, Matrix b) throws InterruptedException, ExecutionException {
		int n = a.getDim();
		Matrix c = new Matrix(n);
		
		/**
		 * Objects matrix of type Future<?>
		 * it is initialized with submit() operation that is sending the tasks for execution
		 */
		Future<?> future = exec.submit(new MulTask(a, b, c));
		/**
		 * Waits for the computation to complete, and retrieves the result
		 */
		future.get();
		return c;
	}
	
	
	static class MulTask implements Runnable {
		Matrix a, b, c;
	
		/**
		 * 
		 * @param a -  is the first matrix for multiplication
		 * @param b -  the second matrix that need to be multiplied
		 * @param c - the result matrix of the product a x b
		 */
		public MulTask(Matrix a, Matrix b, Matrix c) {
			this.a = a; this.b = b; this.c = c;
		}
		
		/**
		 * This method is called when the thread will starts
		 */
		public void run() {
			try {
				/** Initialize n with the actual dimension of the array*/
				int n = a.getDim();
				/**
				 * The matrices are scalars so the multiplication is scalar 
				 */
				if (n == 1) {
					c.set(0, 0, (a.get(0,0) * b.get(0,0)) + (a.get(0,1) * b.get(1, 0)));									
				} 		
				else {
					/**
					 * The matrix will be splitted into 4 submatrices with equal dimensions 
					 */
					Matrix[][] aa = a.split(), bb = b.split(), cc = c.split();
					/**
					 * obtaining the result through an object matrix of type Future<?>
					 */
					Future<?>[][] future = (Future<?>[][]) new Future[2][2];
					for (int i = 0; i < 2; i++) {
						for (int j = 0; j < 2; j++) {
							//it is initialized with submit() method that sends the tasks for executions
								future[i][j] = exec.submit(new MulTask(aa[i][j], bb[i][j], cc[i][j]));}}
					for (int i = 0; i < 2; i++)
						for (int j = 0; j < 2; j++) 
							//waiting the computations to finish
								 future[i][j].get();
				}
			} catch (Exception ex) { ex.printStackTrace(); }
		}
	}
}