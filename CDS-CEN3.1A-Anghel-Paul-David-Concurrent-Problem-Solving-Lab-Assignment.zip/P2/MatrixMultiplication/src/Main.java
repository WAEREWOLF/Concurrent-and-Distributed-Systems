import java.util.concurrent.ExecutionException;

public class Main {

/** Main class where the matrices are initialized and executor is called
 */	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**
		 * @param a - represents the first matrix for multiplication of type Matrix, @see Matrix.java
		 * @param b - represents the second matrix for multiplication of type Matrix, @see Matrix.java
		 * @param c - represents the result matrix for multiplication c = a x b 
		 */
		Matrix c = new Matrix(null, 0, 0, 0); /** Initialize the result matrix */
		Matrix a , b;
		int size = 1023; //size of the matrices
		
		/**
		 * Initialize matrices with value 1 on the principal diagonal
		 */
		a = Matrix.create(size);
		b = Matrix.create(size);
		
	//	System.out.println("A:");
		/** Call the function to show the first matrix, works best for smaller values - for testing*/
	//	a.show();
	//	System.out.println("B:");
		/** Call the function to show the second matrix, works best for smaller values - for testing*/
	//	b.show();
		/** start the timer*/
		long start = System.currentTimeMillis();
		System.out.println("Multiplication started ...");
		try {
			/**
			 * the result matrix uses an object matrix of type Future<?> it is initialized in the submit()
			 * method sending the tasks for execution
			 */
			c = MatrixTask.add(a, b);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	System.out.println("C:");
		/** Print the resulted matrix*/
	//	c.show();
		
		/**
		 * flag is used to know if the array a is equal with c because the multiplication must result
		 * an array with value 1 on the principal diagonal, same as the a, b matrix
		 * so for validation just compares one of the matrix a or b with the result of array c
		 */
		boolean flag = true;
		for(int i =0;i<size;i++) {
			for(int j = 0; j<size;j++) {
				if (a.get(i, j) != c.get(i, j)) 
		               flag = false;
			}
		}
		/**
		 * computing the elapsed time using formula: finish time - starting time
		 */
		long finish = System.currentTimeMillis();
		long timeElapsed = finish - start;
		System.out.println("Parallel multiplication done! \nElapsed time: "+ timeElapsed + " ms");
		/**
		 * checking on the flag if remains true then the multiplied is correct else is incorrect
		 */
		if(flag)
			System.out.println("The result is validated!");
		else 
			System.out.println("The result doesn't match!");
		
	};
	
	}



