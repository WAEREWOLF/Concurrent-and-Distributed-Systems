
//Implementare cu sincronizare fina folosind LOCK
public class FineList<T> {

	/**
	 * @param head - is the head of the list, the first element
	 * @param counter - represents the current number of elements in the list
	 */
    private Node<Integer> head;
    private int counter = 0;

    /**
     * head is initialized with a smaller value then any value in the list
	 * tail is initialized with a greater value then any other value in the list
     */
    public FineList(){

        head = new Node<Integer>(Integer.MIN_VALUE);
        head.next = new Node<Integer>(Integer.MAX_VALUE);
    }

    @SuppressWarnings("unchecked")
    /**
     * 
     * @param item is the wanted value that will be added to the list
     * @return true if an element was added successfully 
     */
	public boolean add(T item){

        int key = item.hashCode();
        head.lock(); // lock in the head lock
        Node<Integer> predecessorNode = head, currentNode; 
        
        try {
        	currentNode = predecessorNode.next;
            currentNode.lock(); // locks in the current node lock
            try {
            	/**
            	 * iterate through the list until the key is placed in order with other elements value
            	 * (ascending order)
            	 */
                while (currentNode.key < key){
                    predecessorNode.unlock(); // unlocks the predecessor lock
                    predecessorNode = currentNode; 
                    currentNode = currentNode.next;
                    currentNode.lock(); //release the current node lock
                }
                /**
                 * there can't be already the value in the list
                 */
                if(currentNode.key == key){
                    return false;
                }else{
                	/**
                	 * Create a new node with the given value and link the node to the list
                	 */
                    Node<T> newNode = new Node<T>(item);
                    newNode.next = currentNode;
                    predecessorNode.next = newNode;
                    /**
                     * the number of elements is increased and the method will return true
                     */
                    counter++;
                    return true;
                }
            }
            finally {
                currentNode.unlock(); // release the current node lock 
            }
            
        }finally {
            predecessorNode.unlock(); // release the predecessor node lock
        }
    }

    @SuppressWarnings("unchecked")
    /**
     * 
     * @param item - the element that is wanted to be removed 
     * @return true - if the element was removed successfully
     */
	public boolean remove(T item){

        Node<Integer> predecessorNode = head, currentNode = null;
        int key = item.hashCode();
        head.lock(); //locks the head lock

        try {
            predecessorNode = head; 
            currentNode = predecessorNode.next;
            currentNode.lock(); // lock the current node lock
            try {
            	/** Iterate through the list until the searched key element for removal*/
                while(currentNode.key < key){
                    predecessorNode.unlock(); // unlock the predecessor node
                    predecessorNode = currentNode; currentNode = currentNode.next;
                    currentNode.lock(); // lock the current node lock
                }
                /**
                 * compares the searched value with the current element value to see if the searched element is present in the list
                 */
                if (currentNode.key == key){
                    predecessorNode.next = currentNode.next; // break up the links in order to remove the current node
                    /**
                     * the number of elements in the list is decreasing because an element just got removed
                     */
                    counter--; 
                    return true;
                }
                return false;
            }finally { currentNode.unlock();} // release the current node lock
        }finally { predecessorNode.unlock();}  // release the predecessor node lock
    }

     @SuppressWarnings("unchecked")
    /**
     * Checks if an element is present in the Fine list
     * @param item - the element with the value that is wanted to be searched
     * @return true - if the element is found
     */
	public boolean contains(T item){

        Node<Integer> predecessorNode = head, currentNode = null;
        int key = item.hashCode();
        head.lock(); // locks in the head lock

        try {
            predecessorNode = head; currentNode = predecessorNode.next;
            currentNode.lock(); // lock in the current node lock
            try {
                while(currentNode.key <= key){
                	/**
                	 * Iterates through the list and  compares the searched value with the current element 
                	 * value to see if the searched element is founded in the list
                	 */
                    if (currentNode.key == key){
                        return true;
                    }
                    predecessorNode.unlock(); // release predecessor lock
                    predecessorNode = currentNode; currentNode = currentNode.next;
                    currentNode.lock(); //lock the current node lock 
                }
                return false;
            }finally { currentNode.unlock(); } // release the current node lock
        }finally { predecessorNode.unlock(); } // release the predecessor node lock
    }
  
    /**
     * 
     * @param ConsumerId - represents the identity of a thread Consumer that will call the method @see Consumer 
     * @return true - if the element is found and is removed calling the @see remove method from this Class
     * and false if the list is empty
     */
    public boolean consume(int ConsumerId){

        @SuppressWarnings("unchecked")
		Node<T> remove = head.next;
        head.lock(); // locks in the head node lock

        try {
            try {
                remove.lock(); //locks in the remove node lock
                if (counter == 0){ // there are no elements in he list
                    System.out.println("\tConsumer "+ConsumerId+" Empty List!");
                    return false;
                }
                else {
                    System.out.println("\tConsumer "+ConsumerId+" CONSUMED "+remove.key);
                    /**
                	 * calls the method @see remove and extract item from the list
                	 */
                    this.remove((T) remove.item);
                    return true;
                }
            }finally { remove.unlock(); } // unlocks the remove node lock
        }finally { head.unlock(); } // release the  head node lock
    }
}
