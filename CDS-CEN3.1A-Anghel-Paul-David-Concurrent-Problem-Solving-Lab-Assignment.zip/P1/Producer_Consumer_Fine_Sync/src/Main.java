import java.util.concurrent.ThreadLocalRandom;

/**
 * 
 * @author ANGHEL PAUL
 * Main class where the threads are created and started
 */
public class Main {

    public static void main(String[] args) {

    	/**
    	 * @param producersNumber - represents the number of Producer threads - a random integer between [4,10) 
    	 * @param consumersNumber - represents the number of Consumer threads - the number of available processors
    	 */
        int producersNumber = ThreadLocalRandom.current().nextInt(4, 10);
        int consumersNumber = Runtime.getRuntime().availableProcessors();

        /**
         * The shared list between the Producer and Consumer threads
         */
        FineList<Integer> sharedList = new FineList<>();
        /**
         * @param producers - represents an array with all Producer threads that is initialized with the size
         * of producersNumber
         * @param consumers - represents an array with all Consumer threads that is initialized with the 
         * number of available processors 
         */
        Producer[] producers = new Producer[producersNumber];
        Consumer[] consumers = new Consumer[consumersNumber];

        /** Print the generated number of Producer and Consumer threads*/
		System.out.println("CREATED " + producersNumber + " Producers and " + consumersNumber + " Consumers!\n");
        /**
         * All the threads from the producers array are created and started
         */
        for (int i = 0; i < producersNumber; i++){
            producers[i] = new Producer(sharedList,i);
            producers[i].start();
        }
        /**
         * All the threads from the consumers array are created and started
         */
        for (int i = 0; i < consumersNumber; i++){
            consumers[i] = new Consumer(sharedList,i);
            consumers[i].start();
        }
        /**
         * search a value in the shared list 
         */
        while(true) {
        if(sharedList.contains(25)) {
        	System.out.println("\t\tElement 25 found in the list!");
        	break;
        }
      }       
    }
}
