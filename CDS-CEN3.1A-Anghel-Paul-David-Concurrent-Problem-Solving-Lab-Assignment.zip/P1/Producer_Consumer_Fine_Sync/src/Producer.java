
import java.util.concurrent.ThreadLocalRandom;

public class Producer extends Thread {

	/**
	 * @param element -> is the element that will be introduced in to the shared list*/
	private static FineList<Integer> sharedList;
	private int ID;
	private int element;

	/** 
	 * Producer receive through constructor the shared list between the Producer and Consumer, also the special ID 
     * of the current Producer thread 
     * 
	 * @param sharedList - is the shared resource where the producer will add elements 
	 * @param ID - represents the unique identification number of a thread Producer
	 */
	Producer(FineList<Integer> sharedList, int ID) {

		Producer.sharedList = sharedList;
		this.ID = ID;
	}
/**
 * This method is called when the thread starts
 */
	public void run() {

		System.out.println("Producer " + this.ID + " thread has STARTED!");

		while (true) {
			/**
			 * Creating an element of type integer, random between [1,100)
			 */
			element = ThreadLocalRandom.current().nextInt(1, 100);
			/**
			 * adding the element in to the shared list calling @see add from @see FineList.java
			 */
			sharedList.add(element);
			System.out.println("Producer " + this.ID + " PRODUCED " + element);
			try {
				sleep(1000); //Thread will sleep for 1s
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
