public class Consumer extends Thread {

	private static FineList<Integer> sharedList;
	private int ID;

	/**
	 * 
	 * @param sharedList - represents the shared resource between Consumer and Producer thread
	 * @param ID - represents the unique identification number of a thread Consumer
	 */
	Consumer(FineList<Integer> sharedList, int ID) {

		Consumer.sharedList = sharedList;
		this.ID = ID;
	}
	/**
	 * This method is called when the thread starts
	 */
	public void run() {

		System.out.println("Consumer " + this.ID + " thread has started!");

		while (true) {
			try {
				sleep(1000); //Thread will sleep for 1s
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			/**
			 * Method @see consume from @see FineList.java is called and an element will be removed
			 * from the shared list
			 */
			sharedList.consume(this.ID);
		}
	}
}
