import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 
 * @author ANGHEL PAUL
 *
 * @param <T> represents the type of the node 
 */
public class Node<T>{

	/**
	 * @param item - is the value of element  
	 * @param key  - is an hash code with an unique value for every node  
	 * @param next - pointer for the next node in list
	 * @param lock - a lock for the fine-grained synchronization
	 */
    T item;
    int key;
    @SuppressWarnings("rawtypes")
	Node next;
    Lock lock;
/**
 * 
 * @param item - value for the new node
 */
    Node(T item){

        this.item = item;
        this.key = item.hashCode();
        this.lock = new ReentrantLock();
    }
/**
 * 
 * @param key - unique value for the new node
 */
    Node(int key){

        this.item = null;
        this.key = key;
        this.lock = new ReentrantLock();
    }

    /**
     * locks the resource
     */
    void lock(){ 
    	lock.lock(); 
    }
    /**
     * Release the resource
     */
    void unlock(){
    	lock.unlock(); 
    }
}
