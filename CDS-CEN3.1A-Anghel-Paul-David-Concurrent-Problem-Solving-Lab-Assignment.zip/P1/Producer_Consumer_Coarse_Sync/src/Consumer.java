
public class Consumer extends Thread {

	/**@param sharedList - represents the shared resource between Consumer and Producer thread
	 * @param ID - represents the unique identification number of a thread Consumer */
    private static CoarseList<Integer> sharedList;
    private int ID;

    /** Consumer receive through constructor the shared list between the Producer and Consumer, also the special ID 
     * of the current Consumer thread */
    Consumer(CoarseList<Integer> sharedList, int ID){

        Consumer.sharedList = sharedList;
        this.ID = ID;
    }
    /** This method is called when the thread is started */
      public void run(){

        System.out.println("\tConsumer "+this.ID +" thread has STARTED!");

        while (true){

            try {
                sleep(1000); //Thread will sleep for 1s
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            /** Print the shared list with all its components every time the Consumer consume an item
             * uncomment to print the list (the console will get loaded with elements value)*/
            sharedList.printList(); 
            /** Consumes an element from the list, calling a method from 
             * @see CoarseList.java*/
            sharedList.consume(this.ID);                
        }
    }
}
