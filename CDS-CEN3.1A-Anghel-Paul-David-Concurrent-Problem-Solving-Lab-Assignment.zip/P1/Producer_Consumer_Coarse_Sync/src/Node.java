
/** Using linked list nodes to implement a collection of elements that doesn't contain duplicates*/
public class Node<T> {

	/** @param item - is the value of element   
	 *  @param key -  is an hash code with an unique value for every node 
	 *  @param next - represents the next available node in the list*/
    T item;
    int key;
    Node<T> next;
    /**
     * 
     * @param item - value for the new node
     */
    Node(T item){
        this.item = item;
        this.key = item.hashCode();
    }
}
