import java.util.concurrent.ThreadLocalRandom;

public class Producer extends Thread {
	
	/**
	 * @param element - is the element that will be introduced in to the shared list*/
    private static CoarseList<Integer> sharedList;
    private int ID;
    private int element; 

     
    /** Producer receive through constructor the shared list between the Producer and Consumer, also the special ID 
     *  of the current Producer thread
     * 
     * @param sharedList - is the shared resource where the producer will add elements
     * @param ID - represents the unique identification number of a thread Producer
     */
    public Producer(CoarseList<Integer> sharedList, int ID){

        Producer.sharedList = sharedList;
        this.ID = ID;       
    }

    /** This method is called when the Thread starts*/
    public void run(){

        System.out.println("Producer  "+this.ID +" thread has STARTED!");

        while (true){
            /** The produced element is a random generated integer between [1 , 200)*/
        	element = ThreadLocalRandom.current().nextInt(1,200);
        	/** Insert in to the list the created element*/
        	sharedList.add(element);
            System.out.println("Producer "+this.ID+" PRODUCED element "+element);
            try {
                sleep(1000); // Thread will sleep for 1s
            } catch (InterruptedException e) {
                e.printStackTrace();
            }            
        }
    }
}
