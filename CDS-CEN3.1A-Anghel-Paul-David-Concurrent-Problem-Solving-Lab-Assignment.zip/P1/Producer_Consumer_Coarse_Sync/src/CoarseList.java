import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CoarseList<T> { 
	 
	/**@param head - is the head of the list, the first element
	 * @param tail - is the last element of the list
	 * @param lock - an instance of ReentrantLock class for guarding the shared list
	 * @param numberOfElements - represents the current number of elements in the list 
	 */	 
    private Node<T> head, tail;
    private Lock lock = new ReentrantLock();
    private int numberOfElments = 0;

   
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public CoarseList(){
		/**
		 * head is initialized with a smaller value then any value in the list
		 * tail is initialized with a greater value then any other value in the list
		 */
        head = new Node(Integer.MIN_VALUE);
        head.next = tail = new Node(Integer.MAX_VALUE);
	}
   /**
    * 
    * @param item - is the element that will be inserted in the shared list by the Producer
    * @return true if the element is added being not duplicated, and false if the value of the element is already in the list
    */
    public boolean add(T item){

        Node<T> predecessorNode, currentNode;
        int key = item.hashCode();

        lock.lock(); //locks in the resource
        try{
            predecessorNode = head; currentNode = predecessorNode.next;
            while (currentNode.key < key){
                predecessorNode = currentNode; 
                currentNode = currentNode.next;
            }
            /**
             * can't be duplicated values in the list
             */
            if (key == currentNode.key) {
                return false;
            }else {
            	/**
            	 * Create a new node with the given value and link the node to the list
            	 */
                Node<T> node = new Node<T>(item);
                node.next = currentNode; predecessorNode.next = node;
                /**
                 * the number of elements is increased and the method will return true
                 */
                numberOfElments++;
                return true;
            }
        }finally {
            lock.unlock(); //release the resource
        }
    }

    /**
     * 
     * @param item represents the element that will be removed from the list by the Consumer
     * @return true if the searched element is present in the list, and false if the value of the element is not present
     */
    public boolean remove(T item){

        Node<T> predecessorNode, currentNode;
        int key = item.hashCode();

        lock.lock(); //locks in the resource 
        try{
            predecessorNode = head; 
            currentNode = predecessorNode.next;
            /** Iterate through the list until the searched key element for removal*/
            while (currentNode.key < key){
                predecessorNode = currentNode; currentNode = currentNode.next;
            }
            /**
             * compares the searched value with the current element value to see if the searched element is present in the list
             */
            if (key == currentNode.key) {
                predecessorNode.next = currentNode.next; // break up the links in order to remove the current node
                /**
                 * the number of elements in the list is decreasing because an element just got removed
                 */
                numberOfElments--;
                return true;
            }else {
                return false;
            }
        }finally {
            lock.unlock(); // release the lock
        }
    }   
   
    /**
     * 
     * @param ConsumerId represents the identity of a thread Consumer that will call the method @see Consumer 
     * @return true if the element is found and is removed calling the @see remove method from this Class
     * and false if the list is empty
     */
    public boolean consume(int ConsumerId){

        Node<T> remove;

        lock.lock(); // locks in the resource
        try{
        	/**
        	 * the removal is set up for the first element in the list
        	 */
            remove = head.next;
            /**
             * checks if there are no element in the list that means the list must be empty
             */
            if (numberOfElments == 0){
                System.out.println("Consumer "+ConsumerId+": the list is empty!");
                return false;
            }
            else {
            	/**
            	 * calls the method @see remove and extract item from the list
            	 */
                System.out.println("\tConsumer "+ConsumerId+" CONSUMED element "+remove.key);
                this.remove((T) remove.item);
                return true;
            }
        }finally {
            lock.unlock();// release the resource
        }
    }

    /**
     * Method that prints the list
     */
    public void printList(){
        Node<T> currentNode;
        int i = 0;

        lock.lock(); //locks in the shared list
        try {
            currentNode = head.next;
            /**
             * iterate through the list until the end is reached
             */
            while (currentNode.key < tail.key) {

                System.out.println("CoarseList["+i+"] = "+currentNode.key); // print every value of the elements
                currentNode = currentNode.next;
                i++; // increase position
            }
        }finally {
            lock.unlock(); //release the shared list
        }
    }
}
