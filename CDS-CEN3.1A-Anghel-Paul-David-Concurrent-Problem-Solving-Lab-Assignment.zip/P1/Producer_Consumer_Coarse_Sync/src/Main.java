import java.util.concurrent.ThreadLocalRandom;

public class Main {
	
	public static void main(String[] args) {

		/** @param producersNumber - represents the random chosen total number of Producer threads 
		 *  @param consumersNumber - represents the total number of Consumer threads
		 *  @param sharedList - is the shared resource where the Producer inserts elements and Consumer remove elements
		 *  @param producers - is an array of type Producer containing all the Producer threads
		 *  @param consumers - is an array of type Consumer containing all the Consumer threads
		
		/** Choosing a random integer for the number of Producers between [4 , 10) */
		/**
		 *
		 */
		int producersNumber = ThreadLocalRandom.current().nextInt(4, 10);
		/** The number of consumer threads will be assigned as the PC available processors*/
		int consumersNumber = Runtime.getRuntime().availableProcessors();
		
		CoarseList<Integer> sharedList = new CoarseList<>();

		/** Initializing producers array with the size of the chosen number of producers
		 *  and consumers array is initialized with the number of available cores*/
		
		Producer[] producers = new Producer[producersNumber];
		Consumer[] consumers = new Consumer[consumersNumber];
		
		/** Print the generated number of Producer and Consumer threads*/
		System.out.println("CREATED " + producersNumber + " Producers and " + consumersNumber + " Consumers!\n");
		/** Iterate through the producers array and start all the threads of type Producer */
		for (int i = 0; i < producersNumber; i++) {
			producers[i] = new Producer(sharedList, i);
			producers[i].start();
		}
		/** Iterate through the consumers array and start all the threads of type Consumer */
		for (int i = 0; i < consumersNumber; i++) {
			consumers[i] = new Consumer(sharedList, i);
			consumers[i].start();
		}
	}
}
